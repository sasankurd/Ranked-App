import React, { useState, useMemo, useEffect } from 'react';
import { APIProvider, Map, AdvancedMarker, InfoWindow, useMap } from '@vis.gl/react-google-maps';
import { useRanked } from '../context/RankedContext';
import { INITIAL_MAP_PLAYERS, calculateDistanceKm } from '../data/mapData';
import { MapPlayer, TierType } from '../types';
import { getTierForLevel, getTierColor, CATEGORY_METADATA } from '../utils/levelMath';
import {
  MapPin,
  Navigation,
  Search,
  Filter,
  User,
  Shield,
  Trophy,
  Swords,
  MessageCircle,
  Eye,
  Radio,
  Compass,
  CheckCircle2,
  Sparkles,
  Layers,
  Globe,
  Crosshair,
  AlertCircle
} from 'lucide-react';

// Controller component to handle programmatic pan/zoom when selecting players or centering
const MapController: React.FC<{
  targetCoords: { lat: number; lng: number } | null;
  targetZoom?: number;
}> = ({ targetCoords, targetZoom = 12 }) => {
  const map = useMap();

  useEffect(() => {
    if (map && targetCoords) {
      map.panTo(targetCoords);
      if (targetZoom) {
        map.setZoom(targetZoom);
      }
    }
  }, [map, targetCoords, targetZoom]);

  return null;
};

export const PlayersMapView: React.FC = () => {
  const {
    user,
    userLocation,
    locationEnabled,
    enableLocation,
    toggleLocation,
    openUserProfile,
    setActiveFriendId,
    setActiveTab,
    theme
  } = useRanked();

  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  // Local state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTierFilter, setSelectedTierFilter] = useState<'all' | 'mythic_apex' | 'master_plus' | 'friends'>('all');
  const [selectedPlayer, setSelectedPlayer] = useState<MapPlayer | null>(null);
  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
    lat: userLocation?.lat || 37.7749,
    lng: userLocation?.lng || -122.4194
  });
  const [mapZoom, setMapZoom] = useState<number>(3);
  const [panTarget, setPanTarget] = useState<{ lat: number; lng: number } | null>(null);
  const [sortBy, setSortBy] = useState<'distance' | 'level'>('distance');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Sync user location to Alex Hunter's marker coordinates
  const playersWithLiveUser: MapPlayer[] = useMemo(() => {
    return INITIAL_MAP_PLAYERS.map(player => {
      if (player.id === 'usr_me' || player.isCurrentUser) {
        const myCoords = userLocation || { lat: 37.7749, lng: -122.4194 };
        return {
          ...player,
          level: user.level,
          xp: user.xp,
          tier: getTierForLevel(user.level),
          location: {
            ...player.location,
            lat: myCoords.lat,
            lng: myCoords.lng,
            city: userLocation?.city || player.location.city
          }
        };
      }
      return player;
    });
  }, [user.level, user.xp, userLocation]);

  // Compute live distance from current user location
  const playersWithDistance: MapPlayer[] = useMemo(() => {
    const userLat = userLocation?.lat || 37.7749;
    const userLng = userLocation?.lng || -122.4194;

    return playersWithLiveUser.map(p => {
      const dist = calculateDistanceKm(userLat, userLng, p.location.lat, p.location.lng);
      return {
        ...p,
        distanceKm: dist
      };
    });
  }, [playersWithLiveUser, userLocation]);

  // Filter players based on tier, friendship, and search query
  const filteredPlayers = useMemo(() => {
    return playersWithDistance.filter(player => {
      // Tier filter
      if (selectedTierFilter === 'mythic_apex') {
        if (player.tier !== 'Mythic' && player.tier !== 'Apex') return false;
      } else if (selectedTierFilter === 'master_plus') {
        if (!['Mythic', 'Apex', 'Grandmaster', 'Master'].includes(player.tier)) return false;
      } else if (selectedTierFilter === 'friends') {
        if (!player.isFriend && !player.isCurrentUser) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          player.name.toLowerCase().includes(q) ||
          player.handle.toLowerCase().includes(q) ||
          player.location.city.toLowerCase().includes(q) ||
          player.location.country.toLowerCase().includes(q) ||
          player.topCategory.toLowerCase().includes(q)
        );
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'distance') {
        return (a.distanceKm || 0) - (b.distanceKm || 0);
      }
      return b.level - a.level;
    });
  }, [playersWithDistance, selectedTierFilter, searchQuery, sortBy]);

  const handleCenterOnMe = () => {
    if (!locationEnabled) {
      enableLocation();
    }
    const coords = userLocation || { lat: 37.7749, lng: -122.4194 };
    setPanTarget({ lat: coords.lat, lng: coords.lng });
    setMapZoom(11);
    const me = playersWithDistance.find(p => p.isCurrentUser);
    if (me) setSelectedPlayer(me);
  };

  const handleJumpToCity = (lat: number, lng: number, zoom = 10) => {
    setPanTarget({ lat, lng });
    setMapZoom(zoom);
  };

  const handleSelectPlayer = (player: MapPlayer) => {
    setSelectedPlayer(player);
    setPanTarget({ lat: player.location.lat, lng: player.location.lng });
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header & Location Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400">
            <Radio className="w-4 h-4 animate-pulse" />
            <span>Real-Time Polymath Geolocation Network</span>
          </div>
          <h2 className="text-2xl font-bold font-['Outfit'] text-zinc-900 dark:text-zinc-50">
            Global Polymath Radar & Player Map
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            Discover ranked rivals, nearby scholars, and Grandmasters worldwide with verified level badges.
          </p>
        </div>

        {/* Location Toggle Action */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={toggleLocation}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold border transition-all shadow-sm ${
              locationEnabled
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                : 'bg-zinc-100 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
            }`}
          >
            <Crosshair className={`w-4 h-4 ${locationEnabled ? 'text-emerald-500 animate-spin-slow' : 'text-zinc-400'}`} />
            <span>{locationEnabled ? 'Location Active' : 'Enable My Location'}</span>
            <span className={`w-2 h-2 rounded-full ${locationEnabled ? 'bg-emerald-500 shadow-sm shadow-emerald-500' : 'bg-zinc-400'}`} />
          </button>

          <button
            onClick={handleCenterOnMe}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 hover:brightness-110 transition-all shadow-sm"
          >
            <Navigation className="w-3.5 h-3.5 text-amber-400" />
            <span>Locate Me</span>
          </button>
        </div>
      </div>

      {/* KPI Ticker Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900/90 border border-zinc-200/80 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] text-zinc-400 uppercase tracking-wider block font-semibold">
            Players on Radar
          </span>
          <span className="text-lg font-mono font-bold text-zinc-900 dark:text-zinc-100">
            {filteredPlayers.length} Active
          </span>
          <span className="text-[11px] text-zinc-500 block">Across 6 Continents</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900/90 border border-zinc-200/80 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] text-zinc-400 uppercase tracking-wider block font-semibold">
            Your Proximity
          </span>
          <span className="text-lg font-mono font-bold text-amber-600 dark:text-amber-400">
            {userLocation?.city || 'San Francisco, CA'}
          </span>
          <span className="text-[11px] text-zinc-500 block">Your Current Hub</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900/90 border border-zinc-200/80 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] text-zinc-400 uppercase tracking-wider block font-semibold">
            Highest Ranked Global
          </span>
          <span className="text-lg font-mono font-bold text-yellow-500">
            Level 989 · Mythic
          </span>
          <span className="text-[11px] text-zinc-500 block">Dr. Marcus Vance (Geneva)</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900/90 border border-zinc-200/80 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] text-zinc-400 uppercase tracking-wider block font-semibold">
            Nearest Polymath Rival
          </span>
          <span className="text-lg font-mono font-bold text-emerald-500">
            {playersWithDistance.find(p => !p.isCurrentUser)?.distanceKm || 14} km
          </span>
          <span className="text-[11px] text-zinc-500 block">
            {playersWithDistance.find(p => !p.isCurrentUser)?.name.split(' ')[0] || 'Maya'} (Level {playersWithDistance.find(p => !p.isCurrentUser)?.level || 312})
          </span>
        </div>
      </div>

      {/* Main Map & Drawer Container */}
      <div className="relative rounded-3xl overflow-hidden border border-zinc-200 dark:border-zinc-800 bg-zinc-950 shadow-xl min-h-[580px] lg:min-h-[640px] flex flex-col lg:flex-row">
        
        {/* Left Side: Filter, Search, and Player Directory Drawer */}
        <div className={`w-full lg:w-96 flex flex-col border-b lg:border-b-0 lg:border-r border-zinc-200 dark:border-zinc-800 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md z-10 transition-all ${isSidebarOpen ? 'block' : 'hidden lg:block'}`}>
          
          {/* Drawer Header & Search */}
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search player, city, country..."
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/80 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Tier Filters */}
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
              {[
                { id: 'all', label: 'All Players' },
                { id: 'mythic_apex', label: 'Lv. 850+ Apex/Mythic' },
                { id: 'master_plus', label: 'Lv. 450+ Master+' },
                { id: 'friends', label: 'Friends' }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setSelectedTierFilter(f.id as any)}
                  className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg whitespace-nowrap transition-colors ${
                    selectedTierFilter === f.id
                      ? 'bg-amber-500 text-zinc-950 shadow-sm'
                      : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Quick Hub Jump Shortcuts */}
            <div className="flex items-center justify-between text-[11px] text-zinc-400">
              <span>Quick Jumps:</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleJumpToCity(37.7749, -122.4194, 11)}
                  className="hover:text-amber-500 font-medium underline"
                >
                  SF Bay
                </button>
                <span>·</span>
                <button
                  onClick={() => handleJumpToCity(46.2044, 6.1432, 11)}
                  className="hover:text-amber-500 font-medium underline"
                >
                  Geneva
                </button>
                <span>·</span>
                <button
                  onClick={() => handleJumpToCity(35.6762, 139.6503, 11)}
                  className="hover:text-amber-500 font-medium underline"
                >
                  Tokyo
                </button>
                <span>·</span>
                <button
                  onClick={() => handleJumpToCity(20, 0, 2)}
                  className="hover:text-amber-500 font-medium underline"
                >
                  Global
                </button>
              </div>
            </div>
          </div>

          {/* Player Cards List */}
          <div className="flex-1 overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800/60 max-h-[380px] lg:max-h-[500px]">
            {filteredPlayers.length === 0 ? (
              <div className="p-8 text-center text-xs text-zinc-400">
                No players match your radar search criteria.
              </div>
            ) : (
              filteredPlayers.map(p => {
                const tier = getTierForLevel(p.level);
                const tierColor = getTierColor(tier);
                const isSelected = selectedPlayer?.id === p.id;
                const isMe = p.isCurrentUser;

                return (
                  <div
                    key={p.id}
                    onClick={() => handleSelectPlayer(p)}
                    className={`p-3.5 flex items-start gap-3 cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-amber-50/80 dark:bg-amber-950/30 border-l-4 border-amber-500'
                        : isMe
                        ? 'bg-zinc-50 dark:bg-zinc-800/40 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                        : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/50'
                    }`}
                  >
                    {/* Avatar with level badge */}
                    <div className="relative shrink-0">
                      <img
                        src={p.avatar}
                        alt={p.name}
                        referrerPolicy="no-referrer"
                        className={`w-11 h-11 rounded-xl object-cover border-2 shadow-sm ${tierColor.badgeBorder}`}
                      />
                      <span
                        className={`absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded-md font-mono text-[9px] font-bold border shadow-xs ${tierColor.badgeBg} ${tierColor.badgeBorder} ${tierColor.badgeText}`}
                      >
                        Lv.{p.level}
                      </span>
                    </div>

                    {/* Meta info */}
                    <div className="flex-1 min-w-0 space-y-0.5">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-bold font-['Outfit'] truncate text-zinc-900 dark:text-zinc-100 flex items-center gap-1">
                          {p.name}
                          {isMe && <span className="text-[10px] text-amber-500 font-mono font-bold">(You)</span>}
                        </span>
                        <span className="font-mono text-[10px] text-zinc-400 tabular-nums shrink-0">
                          {p.distanceKm !== undefined ? `${p.distanceKm.toLocaleString()} km` : ''}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-zinc-500 dark:text-zinc-400">
                        <span className="truncate">{p.location.city}</span>
                        <span>·</span>
                        <span className={`font-mono font-bold ${tierColor.badgeText}`}>{p.tier}</span>
                      </div>

                      <p className="text-[11px] text-zinc-400 dark:text-zinc-500 line-clamp-1 italic">
                        "{p.statusText}"
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Interactive Google Map */}
        <div className="flex-1 relative h-[480px] lg:h-auto min-h-[460px] bg-zinc-900 flex flex-col">
          
          {/* Map Layer Rendering */}
          <div className="w-full h-full relative">
            <APIProvider apiKey={apiKey} libraries={['marker']}>
              <Map
                mapId="DEMO_MAP_ID"
                defaultCenter={mapCenter}
                defaultZoom={mapZoom}
                gestureHandling="greedy"
                disableDefaultUI={false}
                mapTypeControl={true}
                streetViewControl={false}
                fullscreenControl={true}
                internalUsageAttributionIds={['gmp_git_agentskills_v1']}
                className="w-full h-full"
              >
                <MapController targetCoords={panTarget} targetZoom={mapZoom} />

                {/* Render Advanced Markers for All Active Radar Players */}
                {filteredPlayers.map(player => {
                  const tier = getTierForLevel(player.level);
                  const tierColor = getTierColor(tier);
                  const isSelected = selectedPlayer?.id === player.id;
                  const isMe = player.isCurrentUser;

                  return (
                    <AdvancedMarker
                      key={player.id}
                      position={{ lat: player.location.lat, lng: player.location.lng }}
                      title={`${player.name} (Level ${player.level} - ${tier})`}
                      onClick={() => handleSelectPlayer(player)}
                    >
                      {/* Highly styled custom player pin with Avatar, Tier border, and Level Badge */}
                      <div className="relative group cursor-pointer -translate-x-1/2 -translate-y-1/2 transition-transform hover:scale-110">
                        
                        {/* Glow halo for higher tiers or self */}
                        {(tier === 'Mythic' || tier === 'Apex' || isMe) && (
                          <div
                            className={`absolute inset-0 rounded-2xl blur-md pointer-events-none ${
                              isMe ? 'bg-amber-400/50 animate-ping' : 'bg-yellow-400/40 animate-pulse'
                            }`}
                          />
                        )}

                        <div
                          className={`relative p-0.5 rounded-2xl bg-zinc-950 border-2 shadow-2xl transition-all ${
                            isSelected
                              ? 'ring-4 ring-amber-500 scale-110'
                              : `${tierColor.badgeBorder} hover:scale-105`
                          }`}
                        >
                          <img
                            src={player.avatar}
                            alt={player.name}
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl object-cover bg-zinc-800"
                          />

                          {/* Level Badge Pin */}
                          <div
                            className={`absolute -bottom-2.5 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded font-mono text-[9px] font-extrabold whitespace-nowrap border shadow-md ${tierColor.badgeBg} ${tierColor.badgeBorder} ${tierColor.badgeText}`}
                          >
                            Lv.{player.level}
                          </div>
                        </div>
                      </div>
                    </AdvancedMarker>
                  );
                })}

                {/* InfoWindow for Selected Player */}
                {selectedPlayer && (
                  <InfoWindow
                    position={{ lat: selectedPlayer.location.lat, lng: selectedPlayer.location.lng }}
                    onCloseClick={() => setSelectedPlayer(null)}
                    pixelOffset={[0, -25]}
                  >
                    <div className="p-2 max-w-xs text-zinc-900 space-y-2 font-['Plus_Jakarta_Sans',sans-serif]">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={selectedPlayer.avatar}
                          alt={selectedPlayer.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-xl object-cover border border-zinc-300"
                        />
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold font-['Outfit'] text-zinc-900 truncate">
                            {selectedPlayer.name}
                          </h4>
                          <span className="text-[10px] font-mono text-zinc-500 block">
                            {selectedPlayer.handle} · {selectedPlayer.location.city}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-[10px] font-mono font-semibold pt-1 border-t border-zinc-100">
                        <span className="px-2 py-0.5 rounded bg-zinc-100 text-zinc-800">
                          Level {selectedPlayer.level}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                          {selectedPlayer.tier}
                        </span>
                        {selectedPlayer.distanceKm !== undefined && (
                          <span className="text-zinc-500 ml-auto tabular-nums">
                            {selectedPlayer.distanceKm.toLocaleString()} km away
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-zinc-600 line-clamp-2 leading-relaxed">
                        {selectedPlayer.bio}
                      </p>

                      <div className="flex items-center gap-1.5 pt-2 border-t border-zinc-100">
                        <button
                          onClick={() => openUserProfile(selectedPlayer.id)}
                          className="flex-1 py-1.5 px-2 rounded-lg bg-zinc-900 text-white text-[10px] font-semibold hover:bg-zinc-800 transition-colors text-center"
                        >
                          View Profile
                        </button>
                        {!selectedPlayer.isCurrentUser && (
                          <button
                            onClick={() => {
                              setActiveFriendId(selectedPlayer.id);
                              setActiveTab('chat');
                            }}
                            className="p-1.5 rounded-lg border border-zinc-300 text-zinc-700 hover:bg-zinc-100 transition-colors"
                            title="Direct Message"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {!selectedPlayer.isCurrentUser && (
                          <button
                            onClick={() => setActiveTab('challenges')}
                            className="p-1.5 rounded-lg border border-zinc-300 text-amber-600 hover:bg-amber-50 transition-colors"
                            title="Challenge to Mind Duel"
                          >
                            <Swords className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </InfoWindow>
                )}
              </Map>
            </APIProvider>
          </div>

          {/* Floating Floating HUD Card on Bottom Right (when player is selected) */}
          {selectedPlayer && (
            <div className="absolute bottom-4 right-4 z-20 max-w-sm w-full bg-zinc-950/90 backdrop-blur-md rounded-2xl border border-zinc-800 p-4 text-white shadow-2xl animate-in slide-in-from-bottom-2 duration-150 hidden sm:block">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={selectedPlayer.avatar}
                    alt={selectedPlayer.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-xl object-cover border-2 border-amber-500/80"
                  />
                  <div>
                    <h3 className="text-sm font-bold font-['Outfit'] text-white">
                      {selectedPlayer.name}
                    </h3>
                    <p className="text-[11px] font-mono text-zinc-400">
                      {selectedPlayer.location.city}, {selectedPlayer.location.country}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px] font-bold border border-amber-500/40">
                    Level {selectedPlayer.level}
                  </span>
                  <p className="text-[10px] font-mono text-zinc-400 mt-1 tabular-nums">
                    {selectedPlayer.distanceKm !== undefined ? `${selectedPlayer.distanceKm.toLocaleString()} km away` : ''}
                  </p>
                </div>
              </div>

              <p className="text-xs text-zinc-300 mt-2.5 line-clamp-2 leading-relaxed">
                {selectedPlayer.bio}
              </p>

              <div className="mt-3 pt-3 border-t border-zinc-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => openUserProfile(selectedPlayer.id)}
                  className="flex-1 py-1.5 px-3 rounded-xl bg-amber-500 text-zinc-950 text-xs font-bold hover:brightness-110 transition-all text-center"
                >
                  Inspect Full Profile
                </button>
                {!selectedPlayer.isCurrentUser && (
                  <button
                    onClick={() => {
                      setActiveFriendId(selectedPlayer.id);
                      setActiveTab('chat');
                    }}
                    className="inline-flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-semibold hover:bg-zinc-700 transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Chat</span>
                  </button>
                )}
                {!selectedPlayer.isCurrentUser && (
                  <button
                    onClick={() => setActiveTab('challenges')}
                    className="inline-flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-semibold hover:bg-zinc-700 transition-colors"
                  >
                    <Swords className="w-3.5 h-3.5 text-rose-400" />
                    <span>Duel</span>
                  </button>
                )}
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Polymath Radar Intelligence Guide Strip */}
      <div className="p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-zinc-500 dark:text-zinc-400">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-amber-500 shrink-0" />
          <span>
            <strong>Global Proximity Matchmaking:</strong> Enabling location lets you discover polymaths nearby, view their active study domains, and challenge regional rivals to 1v1 live mind duels.
          </span>
        </div>
        <div className="flex items-center gap-4 shrink-0 font-mono text-[11px]">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400 shadow-xs" />
            Mythic (950+)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-xs" />
            Apex (850+)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-xs" />
            Master (450+)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-xs" />
            Expert (250+)
          </span>
        </div>
      </div>

    </div>
  );
};
