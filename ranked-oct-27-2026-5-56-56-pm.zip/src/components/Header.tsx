import React, { useState } from 'react';
import { useRanked } from '../context/RankedContext';
import { getTierForLevel, getTierColor } from '../utils/levelMath';
import { Volume2, VolumeX, Moon, Sun, Watch, Bell, User, Check, SlidersHorizontal, Flame, Gift } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    user,
    activeTab,
    setActiveTab,
    theme,
    toggleTheme,
    soundEnabled,
    toggleSound,
    setWearablesModalOpen,
    setNotificationsModalOpen,
    setStreakModalOpen,
    switchProfile
  } = useRanked();

  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const tier = getTierForLevel(user.level);
  const tierStyle = getTierColor(tier);

  const navLinks: Array<{ id: 'overview' | 'challenges' | 'map' | 'library' | 'academy' | 'science' | 'leaderboard' | 'social' | 'chat' | 'badges'; label: string }> = [
    { id: 'overview', label: 'Overview' },
    { id: 'challenges', label: 'Challenges' },
    { id: 'map', label: 'Map' },
    { id: 'library', label: 'Library' },
    { id: 'academy', label: 'Videos' },
    { id: 'science', label: 'Science' },
    { id: 'leaderboard', label: 'Leaderboard' },
    { id: 'social', label: 'Feed' },
    { id: 'chat', label: 'Chat' },
    { id: 'badges', label: 'Badges' }
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-200 dark:border-zinc-800 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark (Single text element in display face) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className="flex items-center gap-2.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-md"
          >
            <div className="w-8 h-8 rounded-lg bg-zinc-900 dark:bg-zinc-100 flex items-center justify-center text-white dark:text-zinc-900 font-bold font-['Outfit'] text-sm tracking-wider shadow-sm">
              R
            </div>
            <span className="text-xl font-extrabold tracking-tight font-['Outfit'] text-zinc-900 dark:text-zinc-50 whitespace-nowrap">
              Ranked
            </span>
          </button>
        </div>

        {/* Zone 2: 4-6 concise single-line nav links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          {navLinks.map(link => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'text-zinc-950 dark:text-white bg-zinc-100 dark:bg-zinc-800/80'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-900/60'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & User Quick Access */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          
          {/* Daily Login Streak Counter & Attendance Reward Button */}
          <button
            onClick={() => setStreakModalOpen(true)}
            title={`Daily Login Streak: ${user.streakDays} Days Unbroken. ${user.streakClaimedToday ? 'Bonus Claimed Today ✓' : 'Daily Attendance Bonus Available! 🎁'}`}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold border transition-all ${
              !user.streakClaimedToday
                ? 'bg-amber-500/10 border-amber-500/50 text-amber-600 dark:text-amber-400 shadow-sm animate-pulse'
                : 'bg-zinc-100 dark:bg-zinc-800/80 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-750'
            }`}
          >
            <Flame className={`w-3.5 h-3.5 ${!user.streakClaimedToday ? 'text-orange-500 fill-orange-500' : 'text-zinc-400'}`} />
            <span>{user.streakDays}d</span>
            {!user.streakClaimedToday && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
            )}
          </button>

          {/* Quick Audio & Theme Toggles */}
          <button
            onClick={toggleSound}
            aria-label={soundEnabled ? 'Mute audio' : 'Enable audio'}
            title={soundEnabled ? 'Audio Chimes Enabled' : 'Audio Muted'}
            className="p-2 text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-100 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 opacity-60" />}
          </button>

          <button
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className="p-2 text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-100 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Settings & Connected Apps Hub CTA */}
          <button
            onClick={() => setWearablesModalOpen(true)}
            title="Settings: Sync Reading Apps (Goodreads/Kindle), Movie Apps (Letterboxd) & Fitness Wearables"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-700 dark:text-zinc-300 transition-colors whitespace-nowrap shrink-0"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-500" />
            <span>Settings & Sync</span>
          </button>

          {/* Push Notifications Hub CTA */}
          <button
            onClick={() => setNotificationsModalOpen(true)}
            aria-label="Push notifications settings"
            title="Goal reminders & push notifications"
            className="p-2 text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-100 rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors relative"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-amber-500 rounded-full" />
          </button>

          {/* User Profile Pill & Quick Account Switcher */}
          <div className="relative">
            <button
              onClick={() => setProfileDropdownOpen(prev => !prev)}
              className="flex items-center gap-2 pl-2 pr-2.5 py-1 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors bg-zinc-50 dark:bg-zinc-900/80"
            >
              <img
                src={user.avatar}
                alt={user.name}
                referrerPolicy="no-referrer"
                className="w-7 h-7 rounded-md object-cover"
              />
              <div className="flex flex-col items-start text-left">
                <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 leading-tight">
                  Lvl {user.level}
                </span>
                <span className="text-[10px] font-mono text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                  {tier}
                </span>
              </div>
            </button>

            {/* Profile / Account Switcher Dropdown */}
            {profileDropdownOpen && (
              <div
                className="absolute right-0 mt-2 w-72 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xl p-2 z-50 animate-in fade-in zoom-in-95 duration-100"
                onClick={() => setProfileDropdownOpen(false)}
              >
                <div className="px-3 py-2 border-b border-zinc-100 dark:border-zinc-800 mb-1">
                  <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">{user.name}</p>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">{user.handle} · Level {user.level} {tier}</p>
                  <p className="text-[11px] font-mono text-amber-600 dark:text-amber-400 mt-1 tabular-nums">
                    {user.xp.toLocaleString()} Total XP
                  </p>
                </div>

                <div className="py-1">
                  <p className="px-3 py-1 text-[11px] uppercase tracking-wider font-semibold text-zinc-400">
                    Switch Active Persona:
                  </p>

                  <button
                    onClick={() => switchProfile('usr_me')}
                    className="w-full flex items-center justify-between px-3 py-2 text-xs rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors text-left"
                  >
                    <div>
                      <p className="font-medium text-zinc-800 dark:text-zinc-200">Alex Hunter</p>
                      <p className="text-[10px] text-zinc-500">Level 342 · Expert</p>
                    </div>
                    {user.id === 'usr_me' && <Check className="w-3.5 h-3.5 text-emerald-500" />}
                  </button>

                  <button
                    onClick={() => switchProfile('usr_elena')}
                    className="w-full flex items-center justify-between px-3 py-2 text-xs rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors text-left"
                  >
                    <div>
                      <p className="font-medium text-zinc-800 dark:text-zinc-200">Elena Rostova</p>
                      <p className="text-[10px] text-zinc-500">Level 742 · Grandmaster (Ultra Runner)</p>
                    </div>
                    {user.id === 'usr_elena' && <Check className="w-3.5 h-3.5 text-emerald-500" />}
                  </button>

                  <button
                    onClick={() => switchProfile('usr_marcus')}
                    className="w-full flex items-center justify-between px-3 py-2 text-xs rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors text-left"
                  >
                    <div>
                      <p className="font-medium text-zinc-800 dark:text-zinc-200">Dr. Marcus Vance</p>
                      <p className="text-[10px] text-zinc-500">Level 989 · Mythic (10 Years Mastery)</p>
                    </div>
                    {user.id === 'usr_marcus' && <Check className="w-3.5 h-3.5 text-emerald-500" />}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center overflow-x-auto px-4 py-2 border-t border-zinc-200 dark:border-zinc-800 gap-2 scrollbar-none">
        {navLinks.map(link => {
          const isActive = activeTab === link.id;
          return (
            <button
              key={link.id}
              onClick={() => setActiveTab(link.id)}
              className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
                isActive
                  ? 'text-zinc-950 dark:text-white bg-zinc-200 dark:bg-zinc-800'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
              }`}
            >
              {link.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
