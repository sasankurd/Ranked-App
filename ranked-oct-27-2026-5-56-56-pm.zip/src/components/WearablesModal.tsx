import React, { useState } from 'react';
import { useRanked } from '../context/RankedContext';
import { WEARABLE_PREVIEW_PATH } from '../data/mockData';
import {
  X,
  Check,
  Watch,
  Activity,
  RefreshCw,
  BookOpen,
  Film,
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';
import { UserProfile } from '../types';

type IntegrationTab = 'fitness' | 'reading' | 'movies';

export const WearablesModal: React.FC = () => {
  const {
    wearablesModalOpen,
    setWearablesModalOpen,
    user,
    syncWearables,
    isSyncingWearable,
    syncReadingApps,
    syncMovieApps,
    isSyncingReading,
    isSyncingMovies,
    toggleConnectedApp
  } = useRanked();

  const [activeTab, setActiveTab] = useState<IntegrationTab>('reading');

  if (!wearablesModalOpen) return null;

  const fitnessIntegrations: Array<{
    id: keyof UserProfile['connectedWearables'];
    brandKey: 'strava' | 'appleWatch' | 'garmin';
    name: string;
    category: string;
    description: string;
    connected: boolean;
    badge?: string;
  }> = [
    {
      id: 'strava',
      brandKey: 'strava',
      name: 'Strava GPS',
      category: 'Running & Cycling',
      description: 'Syncs verified outdoor distance, elevation gain, and segment PRs directly into your Fitness pillar.',
      connected: !!user.connectedWearables.strava,
      badge: 'Popular'
    },
    {
      id: 'appleWatch',
      brandKey: 'appleWatch',
      name: 'Apple Watch Ultra',
      category: 'Heart Rate & Active Energy',
      description: 'Imports daily active move rings, VO2 max metrics, and gym workouts automatically.',
      connected: !!user.connectedWearables.appleWatch
    },
    {
      id: 'garmin',
      brandKey: 'garmin',
      name: 'Garmin Connect',
      category: 'Endurance & Triathlon',
      description: 'High-precision telemetry for marathon pacing, multisport, and training readiness.',
      connected: !!user.connectedWearables.garmin
    },
    {
      id: 'whoop',
      brandKey: 'strava',
      name: 'Whoop 4.0',
      category: 'Recovery & Strain',
      description: 'Sleep performance, circadian strain logs, and recovery heart rate variability telemetry.',
      connected: !!user.connectedWearables.whoop
    }
  ];

  const readingIntegrations: Array<{
    id: keyof UserProfile['connectedWearables'];
    brandKey: 'goodreads' | 'kindle' | 'appleBooks' | 'storyGraph';
    name: string;
    category: string;
    description: string;
    connected: boolean;
    badge?: string;
  }> = [
    {
      id: 'goodreads',
      brandKey: 'goodreads',
      name: 'Goodreads Shelf',
      category: 'Reading Social & Reviews',
      description: 'Syncs "Read" and "Want to Read" shelves. Automatically verifies completed literature for Literature XP.',
      connected: !!user.connectedWearables.goodreads,
      badge: 'Popular'
    },
    {
      id: 'kindle',
      brandKey: 'kindle',
      name: 'Amazon Kindle Whispersync',
      category: 'E-Reader Telemetry',
      description: 'Reads verified digital page turns, reading speed, and finished books directly from your Kindle library.',
      connected: !!user.connectedWearables.kindle,
      badge: 'Auto-Sync'
    },
    {
      id: 'appleBooks',
      brandKey: 'appleBooks',
      name: 'Apple Books Library',
      category: 'iOS & macOS Reading',
      description: 'Imports completed titles, audiobooks, and highlighted passages into your ranked books archive.',
      connected: !!user.connectedWearables.appleBooks
    },
    {
      id: 'storyGraph',
      brandKey: 'storyGraph',
      name: 'The StoryGraph',
      category: 'Mood & Pace Analytics',
      description: 'Imports book page counts, genres, pacing metrics, and star ratings into your Literature profile.',
      connected: !!user.connectedWearables.storyGraph
    }
  ];

  const movieIntegrations: Array<{
    id: keyof UserProfile['connectedWearables'];
    brandKey: 'letterboxd' | 'imdb' | 'trakt';
    name: string;
    category: string;
    description: string;
    connected: boolean;
    badge?: string;
  }> = [
    {
      id: 'letterboxd',
      brandKey: 'letterboxd',
      name: 'Letterboxd Diary',
      category: 'Social Cinema & Reviews',
      description: 'Syncs film logs, 5-star ratings, and watch dates into your Cinema Canon for +2,200 XP per film.',
      connected: !!user.connectedWearables.letterboxd,
      badge: 'Auteur Choice'
    },
    {
      id: 'imdb',
      brandKey: 'imdb',
      name: 'IMDb Rated Watchlist',
      category: 'Film Database & Ratings',
      description: 'Imports user ratings, rated films, and watch history from your IMDb account automatically.',
      connected: !!user.connectedWearables.imdb
    },
    {
      id: 'trakt',
      brandKey: 'trakt',
      name: 'Trakt.tv Scrobbler',
      category: 'Automated Media Tracking',
      description: 'Scrobbles watched movies and cinema releases directly from Plex, Apple TV, and streaming apps.',
      connected: !!user.connectedWearables.trakt,
      badge: 'Auto-Scrobble'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-2xl rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 p-6 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-['Outfit'] text-zinc-900 dark:text-zinc-100">
                Connected Apps & Telemetry Sync
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Link reading apps, movie watchlists, and smartwatches for automated verification.
              </p>
            </div>
          </div>
          <button
            onClick={() => setWearablesModalOpen(false)}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-3 gap-2 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700/60 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('reading')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg transition-all ${
              activeTab === 'reading'
                ? 'bg-white dark:bg-zinc-900 text-amber-600 dark:text-amber-400 shadow-sm font-bold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Reading Apps ({readingIntegrations.filter(i => i.connected).length})</span>
          </button>

          <button
            onClick={() => setActiveTab('movies')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg transition-all ${
              activeTab === 'movies'
                ? 'bg-white dark:bg-zinc-900 text-pink-600 dark:text-pink-400 shadow-sm font-bold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            <Film className="w-4 h-4" />
            <span>Movie Apps ({movieIntegrations.filter(i => i.connected).length})</span>
          </button>

          <button
            onClick={() => setActiveTab('fitness')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg transition-all ${
              activeTab === 'fitness'
                ? 'bg-white dark:bg-zinc-900 text-emerald-600 dark:text-emerald-400 shadow-sm font-bold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Fitness & Watches</span>
          </button>
        </div>

        {/* TAB 1: READING APPS */}
        {activeTab === 'reading' && (
          <div className="space-y-4 animate-in fade-in-50 duration-150">
            {/* Banner with One-Click Sync */}
            <div className="p-4 rounded-xl border border-amber-200 dark:border-amber-900/50 bg-gradient-to-r from-amber-50/80 to-amber-100/30 dark:from-amber-950/30 dark:to-zinc-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-mono text-amber-600 dark:text-amber-400 font-bold uppercase tracking-wider block">
                  Automated Reading Shelf Sync
                </span>
                <p className="text-xs text-zinc-700 dark:text-zinc-300 mt-0.5">
                  Import completed books and verified page counts from Kindle, Goodreads, Apple Books, and StoryGraph.
                </p>
              </div>

              <button
                disabled={isSyncingReading}
                onClick={() => syncReadingApps('kindle')}
                className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 transition-colors shadow-sm disabled:opacity-50 shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingReading ? 'animate-spin' : ''}`} />
                <span>{isSyncingReading ? 'Syncing Shelves...' : 'Sync Reading List Now'}</span>
              </button>
            </div>

            {/* Reading Services List */}
            <div className="space-y-3">
              {readingIntegrations.map(item => (
                <div
                  key={item.id}
                  className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">{item.name}</h4>
                      {item.badge && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-medium bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-300/40 dark:border-amber-800/40">
                          {item.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {item.connected && (
                      <button
                        disabled={isSyncingReading}
                        onClick={() => syncReadingApps(item.brandKey)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 transition-colors disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncingReading ? 'animate-spin' : ''}`} />
                        <span>Sync Now</span>
                      </button>
                    )}

                    <button
                      onClick={() => toggleConnectedApp(item.id)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                        item.connected
                          ? 'border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100'
                          : 'border-amber-500 bg-amber-500 text-zinc-950 font-bold hover:bg-amber-400'
                      }`}
                    >
                      {item.connected ? 'Disconnect' : 'Connect Account'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: MOVIE APPS */}
        {activeTab === 'movies' && (
          <div className="space-y-4 animate-in fade-in-50 duration-150">
            {/* Banner with One-Click Sync */}
            <div className="p-4 rounded-xl border border-pink-200 dark:border-pink-900/50 bg-gradient-to-r from-pink-50/80 to-pink-100/30 dark:from-pink-950/30 dark:to-zinc-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-mono text-pink-600 dark:text-pink-400 font-bold uppercase tracking-wider block">
                  Automated Cinema Diary & Watchlist Sync
                </span>
                <p className="text-xs text-zinc-700 dark:text-zinc-300 mt-0.5">
                  Import watched films, ratings, and diary entries from Letterboxd, IMDb, and Trakt.tv.
                </p>
              </div>

              <button
                disabled={isSyncingMovies}
                onClick={() => syncMovieApps('letterboxd')}
                className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold rounded-xl bg-pink-600 hover:bg-pink-500 text-white transition-colors shadow-sm disabled:opacity-50 shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingMovies ? 'animate-spin' : ''}`} />
                <span>{isSyncingMovies ? 'Syncing Diary...' : 'Sync Watchlist Now'}</span>
              </button>
            </div>

            {/* Movie Services List */}
            <div className="space-y-3">
              {movieIntegrations.map(item => (
                <div
                  key={item.id}
                  className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">{item.name}</h4>
                      {item.badge && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-medium bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300 border border-pink-300/40 dark:border-pink-800/40">
                          {item.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {item.connected && (
                      <button
                        disabled={isSyncingMovies}
                        onClick={() => syncMovieApps(item.brandKey)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-pink-600 hover:bg-pink-500 text-white transition-colors disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncingMovies ? 'animate-spin' : ''}`} />
                        <span>Sync Now</span>
                      </button>
                    )}

                    <button
                      onClick={() => toggleConnectedApp(item.id)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                        item.connected
                          ? 'border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100'
                          : 'border-pink-600 bg-pink-600 text-white hover:bg-pink-500'
                      }`}
                    >
                      {item.connected ? 'Disconnect' : 'Connect Account'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: FITNESS & SMARTWATCHES */}
        {activeTab === 'fitness' && (
          <div className="space-y-4 animate-in fade-in-50 duration-150">
            {/* Wearable Preview Banner */}
            <div className="relative rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-800 bg-zinc-950 h-32">
              <img
                src={WEARABLE_PREVIEW_PATH}
                alt="Wearable Telemetry"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover opacity-75"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent p-4 flex flex-col justify-end">
                <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider font-semibold">
                  Live Biometric GPS Engine
                </span>
                <p className="text-xs text-zinc-200 font-medium">
                  Every verified kilometer and active calorie pushes your Level 1–1,000 rank forward.
                </p>
              </div>
            </div>

            {/* Fitness Integrations List */}
            <div className="space-y-3">
              {fitnessIntegrations.map(item => (
                <div
                  key={item.id}
                  className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">{item.name}</h4>
                      <span className="text-[11px] text-zinc-400">· {item.category}</span>
                    </div>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {item.connected && (
                      <button
                        disabled={isSyncingWearable}
                        onClick={() => syncWearables(item.brandKey)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncingWearable ? 'animate-spin' : ''}`} />
                        <span>Sync Activity</span>
                      </button>
                    )}

                    <button
                      onClick={() => toggleConnectedApp(item.id)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                        item.connected
                          ? 'border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100'
                          : 'border-emerald-600 bg-emerald-600 text-white hover:bg-emerald-500'
                      }`}
                    >
                      {item.connected ? 'Disconnect' : 'Connect Account'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
          <p className="text-[11px] text-zinc-400">
            End-to-end OAuth telemetry sync encrypted with local client verification.
          </p>
          <button
            onClick={() => setWearablesModalOpen(false)}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
